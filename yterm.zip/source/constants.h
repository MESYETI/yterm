#ifndef YTERM_CONSTANTS_H
#define YTERM_CONSTANTS_H

#define APP_NAME    "yterm"
#define APP_VERSION "dev version"
#define APP_AUTHOR  "yeti0904"
#define APP_DESC    "The terminal emulator of the 27th century"
#define TERM        "xterm-16color"

#endif
