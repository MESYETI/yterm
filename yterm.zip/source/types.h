#ifndef YTERM_TYPES_H
#define YTERM_TYPES_H

typedef struct Vec2 {
	int x;
	int y;
} Vec2;

#endif
