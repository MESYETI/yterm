#ifndef YTERM_ESCAPES_H
#define YTERM_ESCAPES_H

#include "terminal.h"
#include "components.h"

void HandleEscape(Terminal* terminal);

#endif
