# doc
Some documentation for yterm

- [config](/doc/config.md) - info on configuring yterm
